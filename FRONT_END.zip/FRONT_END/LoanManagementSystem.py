from flask import Flask, render_template,request
import psycopg2

#making a connection with the database
conn = psycopg2.connect(
    dbname="group_23",
    user="group_23",
    password="RN1f78hxfRg0Ey",
    host="10.17.6.95",
    port="5432"
)



app = Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')
@app.route('/bank_login')
def bank_login():
    return  render_template('Bank_login.html')

@app.route('/client_login')
def client_login():
    return  render_template('Client_login.html',method = "POST")

@app.route('/client')
def client():
    client_id = request.args.get('client-id')


    # Create a cursor object
    cur = conn.cursor()

    #fetch details of the client
    cur.execute("SELECT A2 AS district_name,\
                    CASE\
                        WHEN LENGTH(birth_number)>6 THEN CONCAT('19', SUBSTR(birth_number, 1, 2), '-', SUBSTR(birth_number, 3, 2), '-', SUBSTR(birth_number, 8, 2))\
                        ELSE CONCAT('19', SUBSTR(birth_number, 1, 2), '-', SUBSTR(birth_number, 3, 2), '-', SUBSTR(birth_number, 5, 2))\
                    END AS birth_date,\
                    CASE\
                        WHEN LENGTH(birth_number)>6 THEN 'Female'\
                        ELSE 'Male'\
                    END AS gender\
                FROM Client\
                JOIN Demography ON (Client.district_id = Demography.district_id)\
                WHERE client_id = %s", (client_id,))
    client = cur.fetchall()

    #fetch total balance of the client

    cur.execute("WITH MAX_Trans(trans_id , account_id) AS (\
                    SELECT MAX(trans_id) as trans_id , account_id\
                    FROM Transaction\
                    GROUP BY account_id\
                )\
                SELECT SUM(balance) as Balance\
                FROM Transaction JOIN MAX_Trans\
                    ON(Transaction.account_id = MAX_Trans.account_id\
                        AND MAX_Trans.trans_id = Transaction.trans_id)\
                    JOIN Disposition\
                    ON (Disposition.account_id = Transaction.account_id\
                        AND Disposition.client_id = %s)", (client_id,))
    balance = cur.fetchall();

    cur.close()


    return render_template('Client.html', client_id = client_id,client=client,balance = balance)

@app.route('/bank')
def bank():
    bank_id = request.args.get('bank-id')
    return render_template('Bank.html',bank_id = bank_id)

@app.route('/loans')
def loans():
    client_id = request.args.get('client_id')
    # Fetch loans data
    loans = get_loans(client_id)
    # Render loans.html template and pass loans data to it
    return render_template('loans.html', client_id=client_id,loans=loans)

@app.route('/cards')
def cards():
    client_id = request.args.get('client_id')
    # Fetch cards data
    cards = get_cards(client_id)
    return render_template('cards.html', client_id=client_id,cards=cards)

@app.route('/scores')
def scores():
    client_id = request.args.get('client_id')
    # Fetch cards data
    scores = get_score(client_id)
    return render_template('scores.html', client_id=client_id,scores=scores)

@app.route('/history')
def history():
    client_id = request.args.get('client_id')
    history = get_history(client_id)
    return render_template('history.html', client_id=client_id,history = history)

@app.route('/accounts')
def accounts():
    bank_id = request.args.get('bank_id')
    accounts = get_all_accounts(bank_id)
    return render_template('Accounts.html', bank_id=bank_id,accounts = accounts)

@app.route('/acc_loans')
def acc_loans():
    account_id = request.args.get('account_id')
    acc_loans = get_account_loans(account_id)
    return render_template('acc_loans.html',account_id=account_id,acc_loans = acc_loans)

@app.route('/acc_add')
def acc_add():
    return render_template('acc_add.html')
def get_loans(client_id):
    # Create a cursor object
    cur = conn.cursor()
    # Fetch loan information for the client
    cur.execute("SELECT l.account_id , l.loan_id, l.amount, l.duration,\
                    l.payments as Monthly_payments, l.status\
                FROM Loan l JOIN Disposition d ON l.account_id = d.account_id\
                WHERE d.client_id = %s\
                ORDER BY l.loan_id", (client_id,))

    loans = cur.fetchall()
    cur.close()
    return loans

def get_cards(client_id):
    # Create a cursor object
    cur = conn.cursor()
    # Fetch loan information for the client
    cur.execute("SELECT card_id, type, issued\
                 FROM Credit_Card\
                 WHERE disp_id IN (\
	             SELECT disp_id\
	             FROM Disposition\
	             WHERE client_id = %s\
                 )ORDER BY card_id", (client_id,))

    cards = cur.fetchall()
    cur.close()
    return cards

def get_score(client_id):
    # Create a cursor object
    cur = conn.cursor()
    # Fetch loan information for the client
    cur.execute("WITH client_transactions AS (\
                    SELECT t.account_id,\
                    SUM(CASE WHEN t.type = 'PRIJEM' THEN t.amount ELSE 0 END) AS total_credit,\
                    SUM(CASE WHEN t.type = 'VYDAJ' THEN t.amount ELSE 0 END) AS total_debit,\
                    (CASE WHEN t.account_id is NOT NULL THEN COUNT(*) ELSE 0 END) AS transaction_count\
                    FROM \
                    Transaction t\
                    JOIN Disposition d ON t.account_id = d.account_id\
                    JOIN Client c ON d.client_id = c.client_id\
                    WHERE \
                    c.client_id = %s\
                    GROUP BY \
                    t.account_id\
                    ),\
                    client_loans AS (\
                    SELECT \
                    l.account_id,\
                    COUNT(*) AS loan_count,\
                    SUM(CASE WHEN l.status = 'A' OR l.status = 'C'\
                        THEN 0 ELSE 1 END) AS defaulted_loans\
                    FROM \
                    Loan l\
                    JOIN Disposition d ON l.account_id = d.account_id\
                    JOIN Client c ON d.client_id = c.client_id\
                    WHERE \
                    c.client_id = %s\
                    GROUP BY \
                    l.account_id\
                    )\
                    SELECT\
                    ct.total_credit,\
                    ct.total_debit,\
                    CASE WHEN ct.transaction_count IS NOT NULL THEN ct.transaction_count ELSE 0 END AS transaction_count,\
                    CASE WHEN cl.loan_count IS NOT NULL THEN cl.loan_count ELSE 0 END AS loan_count,\
                    CASE WHEN cl.defaulted_loans IS NOT NULL THEN cl.defaulted_loans ELSE 0 END as defaulted_loans,\
                    CASE WHEN ct.account_id IS NOT NULL THEN ct.account_id ELSE cl.account_id END,\
                    CASE \
                    WHEN cl.defaulted_loans > 0 THEN 'High Risk'\
                    WHEN ct.total_debit > ct.total_credit THEN 'High Risk'\
                    WHEN ct.total_debit > 2*ct.total_credit THEN 'Very High Risk'\
                    WHEN ct.transaction_count < 10 THEN 'Low Activity'\
                    ELSE 'Good'\
                    END AS credit_score\
                    FROM\
                    client_transactions ct\
                    FULL OUTER JOIN client_loans cl ON (ct.account_id = cl.account_id)\
                    ORDER BY ct.account_id,cl.account_id", (client_id,client_id))\

    scores = cur.fetchall()
    cur.close()
    return scores


def get_history(client_id):
    # Create a cursor object
    cur = conn.cursor()
    # Fetch loan information for the client
    cur.execute("SELECT Disposition.account_id,date,Transaction.amount,Transaction.type,Transaction.operation,\
                Transaction.k_symbol\
                FROM Transaction JOIN Disposition ON (Transaction.account_id = Disposition.account_id)\
                WHERE Disposition.client_id = %s\
                ORDER BY date DESC,amount,date\
                LIMIT 5", (client_id,))

    history = cur.fetchall()
    cur.close()
    return history


def get_all_accounts(bank_id):
    # Create a cursor object
    cur = conn.cursor()
    # Fetch loan information for the client
    cur.execute("SELECT Account.account_id, Account.frequency,Account.date,Client.client_id,\
                CASE WHEN LENGTH(birth_number)>6 THEN CONCAT('19', SUBSTR(birth_number, 1, 2), '-',\
                SUBSTR(birth_number, 3, 2), '-', SUBSTR(birth_number, 8, 2))\
                ELSE CONCAT('19', SUBSTR(birth_number, 1, 2), '-', SUBSTR(birth_number, 3, 2),\
                            '-', SUBSTR(birth_number, 5, 2))\
                END AS birth_date,\
                CASE WHEN LENGTH(birth_number)>6 THEN 'Female' ELSE 'Male'\
                END AS gender ,Client.district_id, Disposition.type\
                FROM Account\
                JOIN Disposition ON Account.account_id = Disposition.account_id\
                JOIN Client ON Disposition.client_id = Client.client_id\
                JOIN Transaction ON Account.account_id = Transaction.account_id\
                WHERE Transaction.bank = %s\
                GROUP by Account.account_id,Account.frequency,Account.date,Client.client_id,\
                Client.birth_number,Client.district_id, Disposition.type ", (bank_id,))

    cards = cur.fetchall()
    cur.close()
    return cards

def get_account_loans(account_id):
    # Create a cursor object
    cur = conn.cursor()
    # Fetch loan information for the client
    cur.execute("SELECT *\
                FROM loan\
                WHERE account_id = %s\
                ORDER by loan_id", (account_id,))

    acc_loans = cur.fetchall()
    cur.close()
    return acc_loans

def add_account(district_id,frequency , client_id):
    # Create a cursor object
    cur = conn.cursor()
    # Fetch loan information for the client
    cur.execute(f"BEGIN;\
                INSERT INTO Account (district_id, frequency, date)\
                VALUES ({district_id}, {frequency} ,CURRENT_DATE)\
                INSERT INTO Disposition (client_id, account_id, type)\
                VALUES ({client_id}, (SELECT currval('account_account_id_seq')), 'OWNER');\
                COMMIT;")
    cur.close()

@app.route('/submit_account', methods=['GET', 'POST'])
def submit_account():
    if request.method == 'POST':
        district_id = request.form['district_id']
        frequency = request.form['frequency']
        client_id = request.form['client_id']
        add_account(district_id, frequency, client_id)
        return 'Account created successfully!'
    return render_template('acc_add.html')



if __name__ == '__main__':
    app.run(debug=True)
